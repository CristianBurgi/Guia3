
package g3_eextra1_gps;


public class Persona {
    public String apellido, nombre;

    public Persona(String apellido, String nombre) {
        this.apellido = apellido;
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void ubicarme(GPS gps){
        gps.mover();
        gps.obtenerUltimaPosicion();
    }
    
}
