
package g3_eextra1_gps;

public class GPS {
    private String marca, modelo;
    private Posicion ultimaUbicacion;

    public GPS(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }
    
    public Posicion obtenerUltimaPosicion(){
        System.out.println("Latitud:  "+ultimaUbicacion.getLatitud()+"°");
        System.out.println("Longitud: "+ultimaUbicacion.getLongitud()+"°");
        return null;
    }
    
    public void mover(){
        Posicion ubic = new Posicion(Math.random(),Math.random());
        ultimaUbicacion = ubic;
//        ultimaUbicacion.setLatitud(/*Math.random()*/0.5);
//        ultimaUbicacion.setLongitud(/*Math.random()*/0.2);
    }
}
