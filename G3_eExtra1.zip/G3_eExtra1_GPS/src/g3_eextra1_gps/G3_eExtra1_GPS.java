
package g3_eextra1_gps;


public class G3_eExtra1_GPS {

    public static void main(String[] args) {
        Persona Viajero = new Persona("Viajero", "Juanito");
        GPS ubicacion = new GPS("Garmin","MOD01");
        Posicion a = new Posicion(0,0);
        Viajero.ubicarme(ubicacion);
        System.out.println("");
        Viajero.ubicarme(ubicacion);
    }

}
