
package adoptar;

/*@author Leandro*/
public class Adoptar {

    public static void main(String[] args) {
      
    }

}
