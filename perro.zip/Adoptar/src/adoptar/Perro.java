

package adoptar;

/*@author Leandro*/
public class Perro {

}
