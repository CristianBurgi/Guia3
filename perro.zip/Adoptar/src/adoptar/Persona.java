

package adoptar;

/*@author Leandro*/
public class Persona {

}
