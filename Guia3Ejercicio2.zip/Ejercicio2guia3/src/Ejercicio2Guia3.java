

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

public class Ejercicio2Guia3 {
//Un Kiosco tiene 3 Empleados. Vamos a contar de dos clases. Kiosco, que tendrá los atributos:
//dirección, nombre, cuit y 3 atributos de tipo Empleado; y la clase Empleado posee los atributos:
//nombre, apellido, fecha de ingreso y dni. Usted deberá pensar en que funcionalidad incorporar en
//la clase Kiosoco para que podamos incorporar sólo hasta 3 Empleados y poder mostrar cual es el
//Empleado con mayor antigüedad.
//
//Ahora en el método main de la clase principal usted creará un Kiosco y 3 Empleados, luego
//incorporará al Kisoco esos Empleados y le solicitará al Kiosco que muestre los datos del Empleado
//de mayor antigüedad.
   
    public static void main(String[] args) {
        Kiosco kiosco1 = new Kiosco("santa fe 44", "kiosquin", 252366614);
        Empleado empleado1 = new Empleado("pepe","garcia",39877652, LocalDate.of(2022, Month.MARCH,20));
        Empleado empleado2 = new Empleado("jose","lope",39875552, LocalDate.of(2022, Month.MARCH,24) );
        Empleado empleado3 = new Empleado("peti","gaia",59874123, LocalDate.of(2022, Month.MARCH,10) );
        Empleado empleado4 = new Empleado("tope","garia",58966123, LocalDate.of(2022, Month.MARCH,02) );
        
             
        kiosco1.incorporarEmpleados(empleado1);
        kiosco1.incorporarEmpleados(empleado2);
        kiosco1.incorporarEmpleados(empleado3);
        kiosco1.incorporarEmpleados(empleado4);
        kiosco1.mayorAnt();
    }
    
}
