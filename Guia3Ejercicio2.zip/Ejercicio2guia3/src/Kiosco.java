
import java.util.ArrayList;

public class Kiosco {

    private String direccion;

    private String apellido;

    private long cuit;

    private Empleado empleado1;

    private Empleado empleado2;

    private Empleado empleado3;

    private ArrayList<Empleado> empleado;

    public Kiosco(ArrayList<Empleado> empleado) {
        this.empleado = empleado;
    }

    public ArrayList<Empleado> getEmpleado() {
        return empleado;
    }

    public void setEmpleado(ArrayList<Empleado> empleado) {
        this.empleado = empleado;
    }

    public Kiosco(String direccion, String apellido, long cuit) {
        this.direccion = direccion;
        this.apellido = apellido;
        this.cuit = cuit;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public long getCuit() {
        return cuit;
    }

    public void setCuit(long cuit) {
        this.cuit = cuit;
    }

    public void incorporarEmpleados(Empleado empleado) {

        if (empleado1 == null) {
            this.empleado1 = empleado;
            System.out.println("Felicitaciones, contrataste un empleado");
        } else if (empleado2 == null) {
            this.empleado2 = empleado;
            System.out.println("Felicitaciones, contrataste un empleado");
        } else if (empleado3 == null) {
            this.empleado3 = empleado;
            System.out.println("Felicitaciones, contrataste un empleado");
        } else {
            System.out.println("Felicitaciones, ya tenes muchos empleados");
        }
    }

    public void mayorAnt() {
        if (empleado1.getFechaDeIngreso().isBefore(empleado2.getFechaDeIngreso()) && empleado1.getFechaDeIngreso().isBefore(empleado3.getFechaDeIngreso())) {
            System.out.println("El empleado con mayor antigüedad es: " + empleado1);
        } else if (empleado2.getFechaDeIngreso().isBefore(empleado1.getFechaDeIngreso()) && empleado2.getFechaDeIngreso().isBefore(empleado3.getFechaDeIngreso())) {
            System.out.println("El empleado con mayor antigüedad es: " + empleado2);
        } else if (empleado3.getFechaDeIngreso().isBefore(empleado1.getFechaDeIngreso()) && empleado3.getFechaDeIngreso().isBefore(empleado2.getFechaDeIngreso())) {
            System.out.println("El empleado con mayor antigüedad es: " + empleado3);
        } else {
            System.out.println("Algo raro hay con las fechas");
        }
    }
}
