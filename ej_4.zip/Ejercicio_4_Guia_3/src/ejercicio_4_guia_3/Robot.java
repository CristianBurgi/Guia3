/* Avanzar(cantidad de pasos)
• Retroceder(cantidad de Pasos)
• Dormir()
• Despertar()
• Recargar()
• bateriaLLena():boolean
• bateriaVacia() :boolean
• energiaActual() :int
 */
package ejercicio_4_guia_3;

public class Robot {
    double bateria = 1000;
    boolean durmiendo = false;
    
    
    public void avanzar(int pasos){
        if (bateria >= pasos/100 && durmiendo == false) {
            bateria -= (pasos/100);
            System.out.println("El Robot esta Avanzando....");
        }else {
            System.out.println("No puede avanzar....");
        }
    }
    
    public void retroceder(int pasos){
        if (bateria >= pasos/100 && durmiendo == false) {
            bateria -= (pasos/100);
            System.out.println("El Robot esta Retrocediendo....");
        }else {
            System.out.println("No puede Retroceder....");
        }
    }
    
    public void dormir(){
        durmiendo = true;
    }
    
    public void despertar(){
        durmiendo = false;
    }
    
    public void recargar(){
        bateria = 1000;
    }
    
    public boolean bateriaLlena(){
        return true;
    }
    
    public boolean bateriaVacia(){
        return false;
    }
    
    public void energiaActual(){
        System.out.println("La bateria actual es: " + bateria);
    }
}
