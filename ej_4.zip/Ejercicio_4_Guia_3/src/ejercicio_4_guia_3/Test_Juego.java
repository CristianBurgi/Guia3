/*Luego desde el método main de una clase TestJuego, se pide:

 Crear un Robot.
 Crear un Hombre y pasarle el Robot creado en el ítem anterior.
 Hacer que el Hombre juegue con el Robot.
 Crear otro Hombre y pasarle el mismo Robot
 Hacer que el último Hombre creado juegue con el Robot,
*/
package ejercicio_4_guia_3;

public class Test_Juego {
    
    public static void main(String[] args) {
        Robot robot = new Robot();
        Hombre hombre = new Hombre();
        hombre.jugarConRobot(robot);
        Hombre hombre2 = new Hombre();
        hombre2.jugarConRobot(robot);
        
    }
}
