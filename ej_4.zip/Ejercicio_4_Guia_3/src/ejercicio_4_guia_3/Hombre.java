
package ejercicio_4_guia_3;

public class Hombre {

    public void jugarConRobot(Robot robot){
        robot.avanzar(500);
        robot.retroceder(20);
        robot.energiaActual();
        robot.dormir();
    }
}
