@TemplateRegistration(folder = "Other", content = "ClassDiagramTemplate.cdg")
package org.uml.filetype.cdg;

import org.netbeans.api.templates.TemplateRegistration;
