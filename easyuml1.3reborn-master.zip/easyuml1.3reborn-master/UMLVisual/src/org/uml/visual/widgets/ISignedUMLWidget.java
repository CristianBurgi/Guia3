package org.uml.visual.widgets;

/**
 *
 * @author Jelena
 */
public interface ISignedUMLWidget {
    public void setSignature(String signature);
    public String getSignature();
}
