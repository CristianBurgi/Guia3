package org.uml.visual.palette;

/**
 *
 * @author NUGS
 */
public class PaletteCategory {
    
    private String name;

    public PaletteCategory() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
